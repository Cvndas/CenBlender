# Pre-selection Highlight

Maya-style pre-selection for Blender's Edit Mode: the vertex, edge or face under the cursor is
highlighted *before* you click, following the current select mode.

- Follows the select mode (vertex = square point, edge = line, face = outline + fill), or optionally highlights vertices, edges and faces in every mode (Highlight setting).
- Occlusion aware (turned off with X-ray), multi-object editing, hidden geometry ignored.
- Numpy-based picking and a per-object cache rebuilt only on geometry/transform changes, so it stays fast.
- Works with the Select tools, and optionally with Move/Rotate/Scale (it steps aside over the tool's gizmo).
- Toggle in Overlays (Edit Mode) or in the add-on preferences; colour, sizes and pick radius are adjustable.

Blender 4.5 LTS or newer. Install via *Preferences > Get Extensions > Install from Disk*.

## Credits / License
GPL-3.0-or-later. Derived from `src/allset/operators/preselect.py` of
[Maya Workflow Kit for Blender](https://github.com/5hyuns/maya-workflow-kit-for-blender), Copyright 2026 ohnsk.
